var canvas2 = document.createElement("CANVAS");
canvas2.setAttribute("width", "200");
canvas2.setAttribute("height", "200");
var ctxBackup = canvas2.getContext('2d');
ctxBackup.fillStyle = "#7de5d5";
ctxBackup.strokeStyle = "black";
ctxBackup.beginPath();
ctxBackup.arc(100, 100, 100, 0, 2 * Math.PI);
ctxBackup.fill();
ctxBackup.stroke();


var chasy = new Image();


chasy.src = "347.png"
chasy.onload = function () {
ctxBackup.drawImage(chasy, 0, 0, 200, 200)

};



function Clock(Left, Top) {
    var interval;

    this.start = function () {
        drawClock();
     
       interval= setInterval(update, 1000);
    }

                

    var ctxClock;
    

    function drawClock() {

        canvas = document.createElement("CANVAS");
        canvas.setAttribute("width","200");
        canvas.setAttribute("height", "200");
        ctxClock = canvas.getContext('2d');
        document.body.appendChild(canvas);
        
        canvas.style.position = "relative";
        canvas.style.left = Left + "px";
        canvas.style.top = Top + "px";

        ctxClock.fillStyle = "#7de5d5";
        ctxClock.strokeStyle = "black";
        ctxClock.beginPath();
        ctxClock.arc(100, 100, 100, 0, 2 * Math.PI);
        ctxClock.fill();
        ctxClock.stroke();
        ctxClock.drawImage(ctxBackup.canvas, 0, 0);

    }

    function drawSeconds() {
        now = new Date();
        //var sec = now.getSeconds();
        ctxClock.translate(100, 100);
        ctxClock.rotate(4.7);
        ctxClock.rotate(now.getSeconds() * 6 * Math.PI / 180);
        ctxClock.beginPath();

        ctxClock.moveTo(-20, 0);
        ctxClock.lineTo(90, 0);
        ctxClock.strokeStyle = "black";
        ctxClock.stroke();


    }
    function drawMinutes() {
        now = new Date();
        //var sec = now.getSeconds();
        ctxClock.translate(100, 100);
        ctxClock.rotate(4.7);
        ctxClock.rotate(now.getMinutes() * 6 * Math.PI / 180);
        ctxClock.beginPath();

        ctxClock.moveTo(0, 0);
        ctxClock.lineTo(80, 0);
        ctxClock.lineWidth = 2;
        ctxClock.strokeStyle = "black";
        ctxClock.stroke();
        if (now.getMinutes() == 30 && now.getSeconds() == 0)
            aud(1);
        if ((now.getMinutes() == 15 || now.getMinutes() == 45) && now.getSeconds() == 0)
            aud(2);




        if (now.getMinutes() == 0 && now.getHours() == 0 && now.getSeconds() < now.getHours() + 12)
            aud(3);
        else {
            if (now.getHours() < 13) {
                if (now.getMinutes() == 0 && now.getSeconds() < now.getHours())
                    aud(3);
            }
            else {
                if (now.getMinutes() == 0 && now.getSeconds() < now.getHours() - 12)
                    aud(3);
            }
        }
    }
    function drawHours() {
        now = new Date();
        var dolya;
        //var sec = now.getSeconds();
        ctxClock.translate(100, 100);
        ctxClock.rotate(4.7);
        if (now.getMinutes() < 12)
            dolya = 0;
        if (now.getMinutes() >= 12)
            dolya = 1;
        if (now.getMinutes() >= 24)
            dolya = 2;
        if (now.getMinutes() >= 36)
            dolya = 3;
        if (now.getMinutes() >= 48)
            dolya = 4;


        ctxClock.rotate(now.getHours() * 30 * Math.PI / 180 + dolya * 6 * Math.PI / 180);
        ctxClock.beginPath();

        ctxClock.moveTo(0, 0);
        ctxClock.lineTo(50, 0);
        ctxClock.lineWidth = 3;
        ctxClock.strokeStyle = "black";
        ctxClock.stroke();
    }

    
    function update() {
        now = new Date();
        ctxClock.drawImage(ctxBackup.canvas, 0, 0);
        ctxClock.save();
        drawSeconds();
        ctxClock.restore();
        ctxClock.save();
        drawMinutes();
        ctxClock.restore();
        ctxClock.save();
        drawHours();
        ctxClock.restore();
       
       
    }
    

}
