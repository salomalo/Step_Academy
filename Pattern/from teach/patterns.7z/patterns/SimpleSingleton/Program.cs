﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleSingleton
{

    public sealed class MySingleton
    {
        private static MySingleton myInstance = null;

        MySingleton()
        {
            Console.WriteLine("Instance created!");
        }

        public static MySingleton Instance
        {
            get
            {
                if (myInstance == null)
                    myInstance = new MySingleton();
                return myInstance;
            }
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            
            var instance = MySingleton.Instance;

            var instance1 = MySingleton.Instance;

            var instance2 = MySingleton.Instance;

            Console.Read();
        }
    }
}

