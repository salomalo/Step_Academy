﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace State
{
    internal static class State
    {
        private static void Main(string[] args)
        {
            //створюємо контекст
            Context context = new Context(new StateA());

            context.OnChange +=context_OnChange;

            while(true)
            {
                //зміна стану A на B.
                context.Request();
                Thread.Sleep(500);
            }

            ////зміна стану B на C.
            //context.Request();

            ////зміна стану C на A.
            //context.Request();
        }

        public static void context_OnChange(IStateBase prev, IStateBase curr)
        {
            Console.WriteLine("Prev: {0} curr {1}",prev.GetType().Name, curr.GetType().Name);
        }
    }

    public interface IStateBase
    {
        void Change(Context context);
    }

    public class StateA : IStateBase
    {
        public void Change(Context context)
        {
            //змінився стан контексту з A на B.
            context.State = new StateB();
         //   Console.WriteLine("Change state from A to B.");
        }
    }

    public class StateB : IStateBase
    {
        public void Change(Context context)
        {
            //змінився стан контексту з B на C.
            context.State = new StateC();
           // Console.WriteLine("Change state from B to C.");
        }
    }

    public class StateC : IStateBase
    {
        public void Change(Context context)
        {
            //змінився стан контексту з C на A.
            context.State = new StateA();
         //   Console.WriteLine("Change state from C to A.");
        }
    }

    public delegate void StateChangeHandler(IStateBase prev, IStateBase curr);

    // клас контекст
    public class Context
    {
        public event StateChangeHandler OnChange;

        public Context(IStateBase state)
        {
            State = state;
            Console.WriteLine("Create object of context class with initial State.");
        }

        public IStateBase State { get; set; }

        //запит на зміну стану
        public void Request()
        {
            var prev = State;

            State.Change(this);

            OnChange(prev, State);

        }
    }
}



