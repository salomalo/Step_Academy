﻿using System;
using System.Text;
using System.Collections.Generic;

namespace Adapter
{
    public interface ITarget
    {
        string GetStringMethod();
    }

    public class MyClient
    {
        private ITarget _target;

        public MyClient(ITarget target)
        {
            _target = target;
        }

        public void DoSomeWork()
        {
            Console.WriteLine("Str: {0}", _target.GetStringMethod());
        }
    }


    public class SensorPanel
    {
        public SensorPanel()
        {

        }

        public byte[] GetData()
        {
            Console.WriteLine("Enter some sensor panel text: ");
            string dataStr = Console.ReadLine();

            return Encoding.ASCII.GetBytes(dataStr);
        }
    }

    public class MyAdapter : SensorPanel, ITarget
    {
        public string GetStringMethod()
        {
            var binData = GetData();

            return Encoding.ASCII.GetString(binData);
        }

    }



    class Adapter
    {
        static void Main(string[] args)
        {
            //ITarget adapter = new MyAdapter();

            var client = new MyClient(new MyAdapter());

            client.DoSomeWork();


            //ITarget itarget = new TrainAdapter();

            //var client = new ThirdPartySystem(itarget);
            //client.ShowTimetable();

            //Console.ReadKey();

        }
    }

   
}