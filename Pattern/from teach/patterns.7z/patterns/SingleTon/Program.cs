﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleTon
{

    //public sealed class SingleLockSingltone
    //{
    //    private static int _counter;
    //    private static readonly SingleLockSingltone _instance = new SingleLockSingltone();

    //    //без статичного конструктора не працюватиме!!!
    //    static SingleLockSingltone()
    //    {

    //    }

    //    public static SingleLockSingltone Instance()
    //    {
    //        return _instance;
    //    }
    //}

    public sealed class SingleLockSingltone
    {
        private static int _counter;
        private static SingleLockSingltone _instance = null;
        private static readonly object padlock = new object();

        private SingleLockSingltone()
        {
            _counter++;
        }

        public static int GetCounter()
        {
            lock (padlock)
            {
                return _counter;
            }
        }

        public void Test()
        {
            Console.WriteLine("Call test()");
        }

        public static SingleLockSingltone Instance()
        {
            lock (padlock)
            {
                if (_instance == null)
                {
                    _instance = new SingleLockSingltone();
                }

                return _instance;
            }
        }
    }

    class TestDumb
    {
        SingleLockSingltone _sn;
        public TestDumb(SingleLockSingltone sn)
        {
            _sn = sn;
        }

        public void DoSomeWork()
        {         

            _sn.Test();
        }
    }

    class TestDumbEx
    {
        public void DoSomeWorkEx()
        {
            var ms = SingleLockSingltone.Instance();

            ms.Test();
        }
    }


    class Program
    {
        static void Main(string[] args)
        {


            var ms = SingleLockSingltone.Instance();


            var ms1 = SingleLockSingltone.Instance();


            //var ms = SingleLockSingltone.Instance();

            TestDumb tt = new TestDumb(ms);

            tt.DoSomeWork();

            TestDumbEx tte = new TestDumbEx();

            tte.DoSomeWorkEx();

            ////ms1

            //for (int i = 0; i < 100; i++)
            //{
            //    var ms3 = SingleLockSingltone.Instance();
            //    Console.WriteLine("Count: {0}", SingleLockSingltone.GetCounter());
            //}


            //Console.WriteLine("Count: {0}", SingleLockSingltone.GetCounter());




        }
    }
}
