﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtMethods
{

    static class  ExtStringMethods
    {
        public static int ToInt32(this string str)
        {
            return Convert.ToInt32(str);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;

            string str = a.ToString();

            int b = str.ToInt32();


            int[] arr = new int[] {1,2,3,4,5,6};

            arr.Where(x => x > 5).ToList();
            

            Console.WriteLine("str : {0}", str);
        }
    }
}
