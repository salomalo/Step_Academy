﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FactoryMethod
{
    //public class Document
    //{
    //    public string Content { get; set; }

    //    public int Length
    //    {
    //        get
    //        {
    //            return Content == null ? 0 : Content.Length;
    //        }
    //    }
    //}

    //public interface IDocStorage
    //{
    //    void Save(string name, Document document);
    //    Document Load(string name);
    //}

    //public abstract class DocumentManager
    //{
    //    private string _name;

    //    public abstract IDocStorage CreateStorage();

    //    public bool Save(Document document)
    //    {
    //        if (this.SaveDialog())
    //        {
    //            //фабричний метод для створення нового сховища документів
    //            IDocStorage storage = this.CreateStorage();

    //            storage.Save(_name, document);

    //            return true;    
    //        }

    //        return false;
    //    }

    //    private bool SaveDialog()
    //    {
    //        Console.WriteLine("Please enter file name to save...");
    //       _name = Console.ReadLine();

    //        return (_name.Length != 0);
    //    }
    //}



    //public class TxtDocumentManager : DocumentManager
    //{
    //    // реалізації IDocStorage розміщуємо як вкладені класи,
    //    // для забезпечення необхідного рівня абстракції сховища
    //    private class TxtDocStorage : IDocStorage
    //    {
    //        public void Save(string name, Document document)
    //        {
    //            Console.WriteLine("Txt file {0} saved", name);
    //        }

    //        public Document Load(string name)
    //        {
    //            return new Document();
    //        }
    //    }

    //    public override IDocStorage CreateStorage()
    //    {
    //        return new TxtDocStorage();
    //    }
    //}

    //public class RtfDocumentManager : DocumentManager
    //{
    //    // реалізації IDocStorage розміщуємо як вкладені класи,
    //    // для забезпечення необхідного рівня абстракції сховища

    //    private class RtfDocStorage : IDocStorage
    //    {
    //        public void Save(string name, Document document)
    //        {
    //           Console.WriteLine("Rtf file {0} saved",name);
    //        }

    //        public Document Load(string name)
    //        {
    //            return new Document();
    //        }
    //    }

    //    public override IDocStorage CreateStorage()
    //    {
    //        return new RtfDocStorage();
    //    }
    //}

    abstract class ComparerProduct
    {
        public abstract int DoCompare(string a, string b);
    }

    class TxtComparerProduct : ComparerProduct
    {
        public override int DoCompare(string a, string b)
        {
            return object.ReferenceEquals(a, b) ? 0 : 1;
        }
    }

    class IntComparerProduct : ComparerProduct
    {
        public override int DoCompare(string a, string b)
        {
            var aa = Convert.ToInt32(a);
            var bb = Convert.ToInt32(b);
            return aa.CompareTo(bb);
        }
    }

    abstract class AbstractCreator
    {
        public abstract ComparerProduct FactoryMethod();
    }

    class TextProductCreator : AbstractCreator
    {
        public override ComparerProduct FactoryMethod()
        {
            return new TxtComparerProduct();
        }
    }

    class IntegerProductCreator : AbstractCreator
    {
        public override ComparerProduct FactoryMethod()
        {
            return new IntComparerProduct();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            AbstractCreator[] arr = { new TextProductCreator(), new IntegerProductCreator() };

            EnumCreators(arr);


            ////зберігаємо txt файл використовуючи "файловий діалог" DocumentManager'a 

            ////в залежності від наслідника, docManager буде Rtf or Txt
            //DocumentManager docManager = new TxtDocumentManager();
            //var document = new Document();
            //docManager.Save(document);


            //// або використавши інтерфейс
            //IDocStorage storage = docManager.CreateStorage();
            //var newDocument = new Document();
            //storage.Save("some.rtf", newDocument);
        }

        private static void EnumCreators(AbstractCreator[] arr)
        {
            foreach (AbstractCreator c in arr)
            {
                ComparerProduct p = c.FactoryMethod();

                StringBuilder a = new StringBuilder();
                a.Append("1");


                StringBuilder b = new StringBuilder();
                b.Append("1");

                Console.WriteLine("1 is equal to 1 = {0}", p.DoCompare(a.ToString(), b.ToString()));
            }
        }
    }


}
