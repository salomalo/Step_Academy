﻿using System;

namespace ChainOfResponsibility
{
    class MainApp
    {   
        static void Main()
        {
            //втсановлюємо ланцюжок відповідальних
            Approver director = new Director();
            Approver vicePresident = new VicePresident();
            Approver president = new President();

            director.SetSuccessor(vicePresident);
            vicePresident.SetSuccessor(president);
            
            ApproveDocument p = new ApproveDocument(1, 350.00, "New printer");
            director.ProcessRequest(p);

            p = new ApproveDocument(2, 33000.0, "Beer machine for programmers");
            director.ProcessRequest(p);

            p = new ApproveDocument(3, 130000.00, "New car for president");
            director.ProcessRequest(p);
            
            Console.ReadKey();
        }
    }
    //абстрактний хендлер
    abstract class Approver
    {
        protected Approver Successor;

        public void SetSuccessor(Approver successor)
        {
            Successor = successor;
        }
        public abstract void ProcessRequest(ApproveDocument approveDocument);
    }

    //конкретний хендлер
    class Director : Approver
    {
        public override void ProcessRequest(ApproveDocument approveDocument)
        {
            if (approveDocument.Amount < 10000.0)
            {
                Console.WriteLine("{0} approved request# {1} {2}", GetType().Name, approveDocument.Number, approveDocument.Purpose);
            }
            else if (Successor != null)
            {
                Successor.ProcessRequest(approveDocument);
            }
        }
    }

    //ще одна реалізація хендлера
    class VicePresident : Approver
    {
        public override void ProcessRequest(ApproveDocument approveDocument)
        {
            if (approveDocument.Amount < 25000.0)
            {
                Console.WriteLine("{0} approved request# {1} {2}", GetType().Name, approveDocument.Number, approveDocument.Purpose);
            }
            else if (Successor != null)
            {
                Successor.ProcessRequest(approveDocument);
            }
        }
    }

    //і ще одна реалізація хендлера
    class President : Approver
    {
        public override void ProcessRequest(ApproveDocument approveDocument)
        {
            if (approveDocument.Amount < 100000.0)
            {
                Console.WriteLine("{0} approved request# {1} {2}", GetType().Name, approveDocument.Number, approveDocument.Purpose);
            }
            else
            {
                Console.WriteLine("Request# {0} {1} requires an executive meeting!",approveDocument.Number,approveDocument.Purpose);
            }
        }
    }

    
    //Tuple<int, double, string>
}