﻿namespace ChainOfResponsibility
{
    class ApproveDocument
    {
        public ApproveDocument(int number, double amount, string purpose)
        {
            Number = number;
            Amount = amount;
            Purpose = purpose;
        }

        // Gets or sets ApproveDocument number
        public int Number { get; set; }

        // Gets or sets ApproveDocument amount
        public double Amount { get; set; }

        // Gets or sets ApproveDocument purpose
        public string Purpose { get; set; }
    }
}