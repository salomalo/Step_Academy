﻿using System;
using System.Collections.Generic;

namespace Mediator
{
    class MainApp
    {
        static void Main()
        {
            // створюємо посередника
            ChatroomMediator chatroomMediator = new ChatroomMediator();

            // реєструємо учасників
            Participant Svitlana = new OurMate("Svitlana");
            Participant Katya = new OurMate("Katya");
            Participant Yuriy = new OurMate("Yuriy");
            Participant DmutroSergiyovuch = new OurMate("DmutroSergiyovuch");

            Participant Vasya = new Stranger("Vasya");

            chatroomMediator.Register(Svitlana);
            chatroomMediator.Register(Katya);
            chatroomMediator.Register(Yuriy);
            chatroomMediator.Register(DmutroSergiyovuch);
            chatroomMediator.Register(Vasya);

            // емулюємо чат
            Vasya.Send("Yuriy", "Hi Yuriy!");
            Katya.Send("Svitlana", "Hello Svitlana!!!");


            DmutroSergiyovuch.Send("Vasya", "Hello stranger");
            Katya.Send("DmutroSergiyovuch", "You did not read the lesson");

            DmutroSergiyovuch.Send("Katya", "I was playing in Angry birds...");


            Console.ReadKey();
        }
    }

    //абстрактний медіатор/посередник
    abstract class AbstractChatroomMediator
    {
        public abstract void Register(Participant participant);
        public abstract void Send(string from, string to, string message);
    }

    //реалізація посередника (чат кімната)
    class ChatroomMediator : AbstractChatroomMediator
    {
        private readonly Dictionary<string, Participant> _participants = new Dictionary<string, Participant>();

        public override void Register(Participant participant)
        {
            if (!_participants.ContainsValue(participant))
            {
                _participants[participant.Name] = participant;
            }

            // встановлюємо посередника для учасника
            participant.ChatroomMediator = this;
        }

        public override void Send(string from, string to, string message)
        {
            Participant participant = _participants[to];
            if (participant != null)
            {
                participant.Receive(from, message);
            }
        }
    }

    //абстрактний колега
    class Participant
    {
        private readonly string _name;

        public Participant(string name)
        {
            _name = name;
        }

        // Імя учасника
        public string Name
        {
            get { return _name; }
        }

        // посилання на медіатора
        public ChatroomMediator ChatroomMediator { get; set; }

        // відсилаємо повідомлення до учасника
        public void Send(string to, string message)
        {
            ChatroomMediator.Send(_name, to, message);
        }

        // отримуємо повідомлення від учасника
        public virtual void Receive(string from, string message)
        {
            Console.WriteLine("{0} to {1}: '{2}'", from, Name, message);
        }
    }

    // реалізація колеги
    class OurMate : Participant
    {
        // Constructor
        public OurMate(string name)    : base(name)
        {
        }

        public override void Receive(string from, string message)
        {
            Console.Write("To a OurMate: ");
            base.Receive(from, message);
        }
    }

    //реалізація колеги
    class Stranger : Participant
    {
        public Stranger(string name)
            : base(name)
        {
        }

        public override void Receive(string from, string message)
        {
            Console.Write("To Stranger: ");
            base.Receive(from, message);
        }
    }
}
