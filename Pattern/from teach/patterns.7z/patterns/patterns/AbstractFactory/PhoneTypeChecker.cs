﻿using System;
using AbstractFactory.Abstract;
using AbstractFactory.Implementation;

namespace AbstractFactory
{
    class PhoneTypeChecker
    {
        private IPhoneFactory _factory;
        private readonly Vendors _menu;

        public PhoneTypeChecker(Vendors m)
        {
            _menu = m;
        }

        public void CheckProducts()
        {
            switch (_menu)
            {
                case Vendors.Samsung:
                    _factory = new SamsungFactory();
                    break;
                case Vendors.Htc:
                    _factory = new HtcFactory();
                    break;
                case Vendors.Nokia:
                    _factory = new NokiaFactory();
                    break;
            }

            Console.WriteLine(_menu.ToString());
            Console.WriteLine("Smart phone: " + _factory.GetSmart().Name);
            Console.WriteLine("Dumb phone: " + _factory.GetDumb().Name);
        }
    }
}