﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AbstractFactory
{
    class Program
    {
        static void Main(string[] args)
        {

            var checker = new PhoneTypeChecker(Vendors.Samsung);

            checker.CheckProducts();

            Console.ReadLine();

            checker = new PhoneTypeChecker(Vendors.Htc);

            checker.CheckProducts();
            Console.ReadLine();

            checker = new PhoneTypeChecker(Vendors.Nokia);

            checker.CheckProducts();
            Console.Read();
        }
    }
}