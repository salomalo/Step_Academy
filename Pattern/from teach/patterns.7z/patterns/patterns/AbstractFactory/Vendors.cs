﻿namespace AbstractFactory
{
    enum Vendors
    {
        Samsung,
        Htc,
        Nokia
    }
}