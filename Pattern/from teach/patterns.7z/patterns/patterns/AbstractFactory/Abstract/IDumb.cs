﻿namespace AbstractFactory.Abstract
{
    interface IDumb
    {
        string Name { get;  }
    }
}