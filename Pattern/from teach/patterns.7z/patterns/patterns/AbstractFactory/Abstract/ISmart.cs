﻿namespace AbstractFactory.Abstract
{
    interface ISmart
    {
        string Name { get; }
    }
}