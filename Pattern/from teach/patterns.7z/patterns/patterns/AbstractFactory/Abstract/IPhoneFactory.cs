﻿namespace AbstractFactory.Abstract
{
    interface IPhoneFactory 
    {
        ISmart GetSmart();
        IDumb GetDumb();
    }
}