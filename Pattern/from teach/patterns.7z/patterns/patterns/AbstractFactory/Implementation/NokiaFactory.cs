﻿using AbstractFactory.Abstract;

namespace AbstractFactory.Implementation
{
    class NokiaFactory : IPhoneFactory
    {
        public ISmart GetSmart()
        {
            return new Lumia();
        }

        public IDumb GetDumb()
        {
            return new Asha();
        }
    }
}