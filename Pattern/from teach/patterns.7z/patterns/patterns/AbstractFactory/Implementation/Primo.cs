﻿using AbstractFactory.Abstract;

namespace AbstractFactory.Implementation
{
    class Primo : IDumb
    {
        public string Name
        {
            get { return "Guru"; }
        }
    }
}