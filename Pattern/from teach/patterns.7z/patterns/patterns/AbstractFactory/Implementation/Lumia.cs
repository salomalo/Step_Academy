﻿using AbstractFactory.Abstract;

namespace AbstractFactory.Implementation
{
    class Lumia : ISmart
    {
        public string Name
        {
            get { return "Lumia"; }
        }
    }
}