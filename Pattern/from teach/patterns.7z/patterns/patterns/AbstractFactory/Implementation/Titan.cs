﻿using AbstractFactory.Abstract;

namespace AbstractFactory.Implementation
{
    class Titan : ISmart
    {
        public string Name
        {
            get { return "Titan"; }
        }
    }
}