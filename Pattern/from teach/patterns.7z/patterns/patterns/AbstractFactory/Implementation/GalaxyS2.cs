﻿using AbstractFactory.Abstract;

namespace AbstractFactory.Implementation
{
    class GalaxyS2 : ISmart
    {
        public string Name
        {
            get { return "GalaxyS2"; }
        }
    }
}