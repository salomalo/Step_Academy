﻿using AbstractFactory.Abstract;

namespace AbstractFactory.Implementation
{
    class Asha : IDumb
    {
        public string Name
        {
            get { return "Asha"; }
        }
    }
}