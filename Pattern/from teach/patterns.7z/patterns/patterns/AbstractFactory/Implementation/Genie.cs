﻿using AbstractFactory.Abstract;

namespace AbstractFactory.Implementation
{
    class Genie : IDumb
    {
        public string Name
        {
            get { return "Genie"; }
        }
    }
}