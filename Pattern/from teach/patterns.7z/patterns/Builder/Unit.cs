﻿using System;
using System.Collections.Generic;

namespace Builder
{
    /// <summary>
    /// Клас продукт
    /// </summary>
    public class Unit
    {
        public string Name { get; set; }
        public int Health { get; set; }
        public int BuildTime { get; set; }
        public int Cost { get; set; }

        public List<string> Attributes { get; set; }

        public Unit()
        {
            Attributes = new List<string>();
        }

        public void ShowInfo()
        {
            Console.WriteLine("Name: {0}", Name);
            Console.WriteLine("BuildTime: {0}", BuildTime);
            Console.WriteLine("Health: {0}", Health);
            Console.WriteLine("Cost: {0}", Cost);
            Console.WriteLine("Attributes:");

            foreach (var attrib in Attributes)
            {
                Console.WriteLine("\t{0}", attrib);
            }
        }
    }
}