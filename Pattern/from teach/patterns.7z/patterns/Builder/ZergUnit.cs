﻿namespace Builder
{
    //конкретний білдер
    public class ZergUnit : IUnitBuilder
    {
        readonly Unit _unit = new Unit();

        public void SetUnitName()
        {
            _unit.Name = "Drone";
        }

        public void SetHealth()
        {
            _unit.Health = 40;
        }

        public void SetBuildTime()
        {
            _unit.BuildTime = 17;
        }

        public void SetCost()
        {
            _unit.Cost = 50;
        }

        public void SetAttributes()
        {
            _unit.Attributes.Add("Biological");
            _unit.Attributes.Add("Light");
        }

        public Unit GetUnit()
        {
            return _unit;
        }
    }
}