﻿namespace Builder
{
    //конкрутний будівельник
    public class TerranUnit : IUnitBuilder
    {
        readonly Unit _unit = new Unit();
        public void SetUnitName()
        {
            _unit.Name = "Scv";
        }
       
        public void SetHealth()
        {
            _unit.Health = 45;
        }

        public void SetBuildTime()
        {
            _unit.BuildTime = 17;
        }

        public void SetCost()
        {
            _unit.Cost = 50;
        }

        public void SetAttributes()
        {
            _unit.Attributes.Add("Biological");
            _unit.Attributes.Add("Light");
            _unit.Attributes.Add("Mechanical");
            
        }

        public Unit GetUnit()
        {
            return _unit;
        }
    }
}