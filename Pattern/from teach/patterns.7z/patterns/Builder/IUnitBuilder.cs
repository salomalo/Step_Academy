﻿namespace Builder
{
    /// <summary>
    /// The 'Builder' interface
    /// </summary>
    public interface IUnitBuilder
    {
        void SetUnitName();
        void SetHealth();
        void SetBuildTime();
        void SetCost();
        void SetAttributes();

        Unit GetUnit();
    }
}