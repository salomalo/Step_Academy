﻿namespace Builder
{
    public class UnitDirector
    {
        private readonly IUnitBuilder _builder;

        public UnitDirector(IUnitBuilder builder)
        {
            _builder = builder;
        }

        //визначає порядок
        public void CreateUnit()
        {
            _builder.SetUnitName();
            _builder.SetBuildTime();
            _builder.SetHealth();
            _builder.SetCost();
            _builder.SetAttributes();
            
        }

        public Unit GetUnit()
        {
            return _builder.GetUnit();
        }
    }
}