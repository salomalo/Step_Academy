﻿using System;

namespace Builder
{
   
    class Program
    {
        static void Main(string[] args)
        {
            //конфігуруємо директора екземпляром конкретного будівельника
            var directorOrCreator = new UnitDirector(new TerranUnit());
            directorOrCreator.CreateUnit();

            //отримуємо результат
            var unit = directorOrCreator.GetUnit();
            unit.ShowInfo();

            Console.WriteLine("---------------------------------------------");

            //конфігуруємо директора екземпляром конкретного будівельника
            directorOrCreator = new UnitDirector(new ZergUnit());
            directorOrCreator.CreateUnit();


            //отримуємо результат
            unit = directorOrCreator.GetUnit();
            unit.ShowInfo();

            Console.ReadKey();
        }
    }
}