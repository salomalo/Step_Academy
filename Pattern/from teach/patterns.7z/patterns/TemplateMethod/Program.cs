﻿using System;

namespace TemplateMethod
{
    class TemplateMethod
    {
        //static void should_process_document()
        //{
        //    var mock = new FileManagerMock();

        //    DocumentManager m = new DocumentManager(mock);

        //    m.Process();

        //    if (mock.LoadCallCount == 1 && mock.SaveCallCount == 1)
        //    {
        //        Console.WriteLine("Test - OK");
        //    }
        //    else
        //    {
        //        Console.WriteLine("Test - FAIL");
        //    }
        //}

        static void Main(string[] args)
        {
            //should_process_document();

            //DocumentManager m = new DocumentManager(new RealFileManager());

            //m.Process();



            Console.WriteLine("Select email account: ");
            Console.WriteLine("1 for Google");
            Console.WriteLine("2 for Yahoo");
            string choice = Console.ReadLine();
            EmailBase email;

            if (choice == "1")
            {
                email = new EmailGoogle();
                email.SendEmail();

            }
            if (choice == "2")
            {
                email = new EmailYahoo();
                email.SendEmail();
            }
        }
    }

    interface IFileManager
    {
        void Load();
        void Save();
    }

  

    public abstract class EmailBase
    {
        public bool SendEmail()
        {
            bool ret = false;

            // будуємо скелетон алгоритму
            if (CheckEmailAddress()) 
            {
                if (ValidateMessage())
                {
                    if (SendMail()) 
                    {
                        ret = true;
                    }
                }
            }
            return ret;
        }

        protected abstract bool CheckEmailAddress();
        protected abstract bool ValidateMessage();
        protected abstract bool SendMail();
    }

    //реалізація алгоритму
    public class EmailYahoo : EmailBase
    {
        protected override bool CheckEmailAddress()
        {
            Console.WriteLine("Checking Email Address : YahooEmail");
            return true;
        }

        protected override bool ValidateMessage()
        {
            Console.WriteLine("Validating Email Message : YahooEmail");
            return true;
        }
        protected override bool SendMail()
        {
            Console.WriteLine("Sending Email : YahooEmail");
            return true;
        }
    }

    //реалізація алгоритму
    public class EmailGoogle : EmailBase
    {
        protected override bool CheckEmailAddress()
        {
            Console.WriteLine("Checking Email Address : GoogleEmail");
            return true;
        }
        protected override bool ValidateMessage()
        {
            Console.WriteLine("Validating Email Message : GoogleEmail");
            return true;
        }

        protected override bool SendMail()
        {
            Console.WriteLine("Sending Email : GoogleEmail");
            return true;
        }
    }

    class FileManagerMock : IFileManager
    {
        public int LoadCallCount { get; private set; }
        public int SaveCallCount { get; private set; }

        public void Load()
        {
            LoadCallCount++;
        }

        public void Save()
        {
            SaveCallCount++;
        }
    }

    class RealFileManager : IFileManager
    {

        public void Load()
        {
            Console.WriteLine("Load");
        }

        public void Save()
        {
            Console.WriteLine("Save");
        }
    }

    class DocumentManager
    {
        IFileManager _manager;
        public DocumentManager(IFileManager manager)
        {
            _manager = manager;
        }
        public void Process()
        {
            //load
            _manager.Load();
            //save
            // _manager.Save();
        }
    }

}
