﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotsFactory
{
    class Program
    {
        

        static void Main(string[] args)
        {
            IRobotsFactory roboFactory = CreateUsaRobotFactory();
 

            Console.WriteLine("Say: {0}", roboFactory.GetMetalRobot().Name);
        }

        private static UsaFactory CreateUsaRobotFactory()
        {
            return new UsaFactory();
        }
    }



    interface IRobotsFactory
    {
        IWoodenRobot GetWoodenRobot();
        IMetalRobot GetMetalRobot();
        IStoneRobot GetStoneRobot();
    }

    internal interface IStoneRobot
    {
    }

    class UsaFactory : IRobotsFactory
    {
        public IWoodenRobot GetWoodenRobot()
        {
            return  new Pinokio();
        }

        public IMetalRobot GetMetalRobot()
        {
           return  new Terminator();
        }

        public IStoneRobot GetStoneRobot()
        {
            throw new NotImplementedException();
        }
    }

    class  UssrFactory : IRobotsFactory 
    {
        public IWoodenRobot GetWoodenRobot()
        {
            return  new Buratino();
        }

        public IMetalRobot GetMetalRobot()
        {
           return new Electronic();
        }

        public IStoneRobot GetStoneRobot()
        {
            throw new NotImplementedException();
        }
    }



    internal interface IMetalRobot
    {
        string Name { get; }
    }

    internal interface IWoodenRobot
    {
        string Name { get; }
    }


     class Terminator : IMetalRobot
    {
        public string Name
        {
            get { return "T-1000"; }
        }
    }

     class Pinokio : IWoodenRobot
    {
        public string Name
        {
            get { return "Wooden pinokio"; }
        }
    }

     class Electronic : IMetalRobot
    {
        public string Name
        {
            get { return "Metal electronic"; }
        }
    }

    class Buratino : IWoodenRobot
    {
        public string Name
        {
            get { return "Wooden buratino"; }
        }
    }
}
