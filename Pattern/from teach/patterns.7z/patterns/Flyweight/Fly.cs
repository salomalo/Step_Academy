﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flyweight
{
    class Program
    {
        static void Main(string[] args)
        {

            FigureFactory factory = new FigureFactory();

            for (int i = 0; i < 100; i++)
            {
                var triangle = factory.GetObj("triangle");

                triangle.Print();

            }

            Circle cc =  (Circle)factory.GetObj("circle");

            cc.Print();

        }
    }



    interface IFigure
    {
        void Print();
    }

    class Figure
    {
        byte[] _img;

        public Figure()
        {
            _img = new byte[1024 * 1024];

            new Random().NextBytes(_img);

        }
    }

    class Circle : Figure, IFigure
    {
        public void Print()
        {
            Console.WriteLine("I am circle!");
        }
    }

    class Triangle : Figure, IFigure
    {
        public void Print()
        {
            Console.WriteLine("I am triangle!");
        }
    }

    class Rectangle : Figure, IFigure
    {
        public void Print()
        {
            Console.WriteLine("I am rectangle!");
        }
    }

    class FigureFactory
    {
        IDictionary<string, IFigure> _figures;

        public FigureFactory()
        {
            _figures = new Dictionary<string, IFigure>();
            Initialize();
        }

        public IFigure GetObj(string key)
        {
            //++
            return _figures[key];
        }


        //public IFigure GetUnsharedObj(string key)
        //{
        //    return _figures[key].DeepClone();
        //}

        private void Initialize()
        {
            string[] shapes = new string []{ "circle","triangle","rectangle"};

            foreach(var shape in shapes)
            {
                IFigure figure = null;

                switch(shape)
                {
                    case "circle":
                        figure = new Circle();
                        break;
                    case "rectangle":
                        figure = new Rectangle();
                        break;
                    case "triangle":
                        figure = new Triangle();
                        break;
                }

                _figures.Add(shape, figure);
            }
        }
    }
}
