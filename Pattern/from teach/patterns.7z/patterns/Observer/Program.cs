﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer
{
    class CellPhoneSubscriber
    {
        public CellPhoneSubscriber(Counter counter)
        {
            counter.EventPool += (value) => { Console.WriteLine("Hello from cell subscriber with value {0}", value); };

           // counter.EventPool -= (value) => { Console.WriteLine("Hello from cell subscriber with value {0}", value); };
        }

        //void counter_CounterChange(int value)
        //{
        //    Console.WriteLine("Hello from cell subscriber with value {0}", value);
        //}
    }

    class Program
    {
        static void Main(string[] args)
        {
            var counter = new Counter();

            var arr = new CellPhoneSubscriber[3];
            for (int i =0; i < arr.Count() - 1; ++i)
            {
                arr[i] = new CellPhoneSubscriber(counter);
            }

            //counter.EventPool += counter_CounterChange;

            DoSomeWork(counter);

            Console.ReadLine();

        }

        //static void counter_CounterChange(int value)
        //{
        //    Console.WriteLine("Counter value: {0}", value);
        //}

        private static void DoSomeWork(Counter c)
        {
            c.Inc();
            c.Inc();
            c.Dec();
            c.Inc();
            c.Inc();
        }
    }

    public delegate void CounterChange(int value);

    class Counter
    {
        public event CounterChange EventPool;
        private int _count;

        public int Count 
        {
            get { return _count; }
            private set
            {
                _count = value;
                if (EventPool != null)
                {
                    EventPool.Invoke(_count);
                }
            }
        }

        public void Inc()
        {
            Count++;
        }

        public void Dec()
        {
            Count--;
        }

    }
}
